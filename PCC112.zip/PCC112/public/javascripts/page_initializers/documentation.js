$(document).ready(function() {
  Elemental.load(document);
  Bookbinder.boot();
});


$(function () {

	if (document.location.pathname.indexOf('/pivotalax/') > -1 ||
        document.location.pathname.indexOf('/chorus/') > -1) {
		document.location.href = "https://alpine.atlassian.net/wiki/display/DOC/Alpine+Overview";
	}
});


// MANUAL ToC REPLACEMENT
// If you create a table of contents with the class 'quick-links'
// in the body of your page, it replaces the automatic table of
// contents whereever it appears
$(function() {
  $('.js-quick-links').wrap('<div class="js-quick-links"></div>').replaceWith($('main > .quick-links'));
});



// NAVIGATION
$(function() {
    // Smooth scrolling for all jump links
    $('a[href*=#]:not([href=#])').click(function() {
        if (location.pathname.replace(/^\//,'') == this.pathname.replace(/^\//,'') && location.hostname == this.hostname) {
            var target = $(this.hash);
            target = target.length ? target : $('[name=' + this.hash.slice(1) +']');
            if (target.length) {
                $('html,body').animate({
                    scrollTop: target.offset().top
                }, 600);
            // return false;
            }
        }
    });

    // Show and hide back to top
    if(jQuery().waypoint) {
        $('#js-to-top').waypoint('sticky', {
          wrapper: '<div class="sticky-wrapper" />',
          stuckClass: 'sticky',
          offset: 100
        });
    }
});

mermaid.initialize({startOnLoad:true});
